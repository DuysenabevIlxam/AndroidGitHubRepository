package com.example.furniq.data.get_products_by_id

data class ImageX(
    val id: Long,
    val url: String,
)
