package com.example.furniq.data.delete_favourite

data class DeleteFavouriteData(
    var success  : Boolean
)