package com.example.furniq.data.latest_data

data class Image(
    val id: Int,
    val url: String
)