package com.example.furniq.data.get_products_by_id

data class Seller(
    val company_name: String,
    val id: Int
)