package com.example.furniq.data.favourites_data

data class FavouritesData(
    val data: List<FData> = listOf()
)