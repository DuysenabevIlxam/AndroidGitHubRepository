package com.example.furniq.data.get_products_by_id

data class Description(
    val kiril: String,
    val latin: String,
    val ru: String
)