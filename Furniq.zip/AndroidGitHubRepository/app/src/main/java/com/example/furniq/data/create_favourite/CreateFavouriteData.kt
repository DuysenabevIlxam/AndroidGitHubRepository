package com.example.furniq.data.create_favourite

data class CreateFavouriteData(
    val success: Boolean
)