package com.example.furniq.data.sign_up_data


import com.google.gson.annotations.SerializedName

data class GetProfileData(
    @SerializedName("data")
    val data: Data
)