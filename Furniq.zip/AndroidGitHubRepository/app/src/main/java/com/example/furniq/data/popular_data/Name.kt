package com.example.furniq.data.popular_data

data class Name(
    val kiril: String,
    val latin: String,
    val ru: String
)