package com.example.furniq.data.popular_data

data class Image(
    val id: Int,
    val url: String
)