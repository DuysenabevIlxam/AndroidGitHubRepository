package com.example.furniq.data.popular_data

data class Description(
    val kiril: String,
    val latin: String,
    val ru: String
)