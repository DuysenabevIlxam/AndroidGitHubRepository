package com.example.furniq

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class ShoppingCartFragment : Fragment(R.layout.fragment_shopping_cart) {



}