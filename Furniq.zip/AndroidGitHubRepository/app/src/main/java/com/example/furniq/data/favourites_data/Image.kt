package com.example.furniq.data.favourites_data

data class Image(
    val id: Int,
    val url: String
)