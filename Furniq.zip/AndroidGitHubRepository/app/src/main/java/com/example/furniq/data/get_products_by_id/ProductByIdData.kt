package com.example.furniq.data.get_products_by_id

data class ProductByIdData(
    val data: PData
)