package com.example.furniq.data.latest_data

data class LatestData(
    val `data`: List<Data>,
    val links: Links,
    val meta: Meta
)