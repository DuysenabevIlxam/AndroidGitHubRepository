package com.example.furniq.data.get_products_by_id

data class Color(
    val id: Int,
    val name: NameXX
)