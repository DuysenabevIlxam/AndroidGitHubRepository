package com.example.furniq.data.popular_data

data class Links(
    val first: Any,
    val last: Any,
    val next: Any,
    val prev: Any
)