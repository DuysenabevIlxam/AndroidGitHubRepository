package com.example.furniq.data.latest_data

data class Description(
    val kiril: String,
    val latin: String,
    val ru: String
)