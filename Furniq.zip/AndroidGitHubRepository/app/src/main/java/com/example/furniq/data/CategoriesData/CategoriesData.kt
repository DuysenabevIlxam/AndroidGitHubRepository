package com.example.furniq.data.CategoriesData

data class CategoriesData(
    val data: List<CData>
)