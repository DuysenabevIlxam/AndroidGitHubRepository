package com.example.furniq.data.favourites_data

data class Name(
    val kiril: String,
    val latin: String,
    val ru: String
)