package com.example.furniq.data.get_all_products_data

data class Name(
    val kiril: String,
    val latin: String,
    val ru: String
)