package com.example.furniq.data.popular_data

data class PopularData(
    val data: List<Data> ,
    val links: Links,
    val meta: Meta
)