package com.example.furniq.data.get_all_products_data

data class Links(
    val first: Any,
    val last: Any,
    val next: Any,
    val prev: Any
)