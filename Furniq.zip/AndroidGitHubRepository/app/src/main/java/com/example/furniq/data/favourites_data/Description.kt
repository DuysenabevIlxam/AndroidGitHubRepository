package com.example.furniq.data.favourites_data

data class Description(
    val kiril: String,
    val latin: String,
    val ru: String
)