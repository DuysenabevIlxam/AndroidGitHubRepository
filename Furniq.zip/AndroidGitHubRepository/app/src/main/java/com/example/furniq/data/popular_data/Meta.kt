package com.example.furniq.data.popular_data

data class Meta(
    val next_cursor: Any,
    val path: String,
    val per_page: Int,
    val prev_cursor: Any
)