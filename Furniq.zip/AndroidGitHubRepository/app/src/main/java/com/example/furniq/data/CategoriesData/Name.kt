package com.example.furniq.data.CategoriesData

data class Name(
    val kiril: String,
    val latin: String,
    val ru: String
)