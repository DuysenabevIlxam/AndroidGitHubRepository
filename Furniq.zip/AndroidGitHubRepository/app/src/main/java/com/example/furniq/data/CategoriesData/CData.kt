package com.example.furniq.data.CategoriesData

data class CData(
    val id: Int,
    val name: Name
)